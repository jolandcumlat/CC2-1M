System.out.println("Hello World!");
	String name = "Glenn";
	int age = 18;
	char sex = 'M';
	String  bday = "June 13, 2000";
	String section = "CITCS-1M";
	String subject = "CC2";
	String code = "Introduction to Computer Programming";
	double pi = 3.1416;
	System.out.println("Name: "+name);
	System.out.println("Age: "+age);
	System.out.println("Sex: "+sex);
	/*System.out.println("Birthdate: "+bday);
	System.out.println("Subject: "+subject);
	System.out.println("Course code: "+code);*/
	System.out.println("Value for Pi: "+pi);
}