public class HelloWorld2 {

    public static void main(String[] args) {
            System.out.println("Hello World!");
            System.out.println("I am John Glenn Galido");
            System.out.println("I am 18 yrs. old");
            System.out.println("I am a Male");
            System.out.println("The value of Pi is 3.1416");
    }
    
}